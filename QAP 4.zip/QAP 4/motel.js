// Description: Creating an object for a Motel Customer
// Authour: Declan Derible
// Date(s): March 22nd-23rd, 2024

const MotelCustomor = {
    cname: "Declan Derible",
    gender: "Male",
    birthdate: "2003-08-15",
    cpayment: "Credit Card",
    phonenumber: "1-709-765-4059",
    roompreference: ["King", "Queen", "Pet-friendly", "Smoke-free"],

    mailingaddress: {
        streetaddress: "42 Wyatt Boulevard",
        town: "Mount Pearl",
        postalcode: "A1N 3H7",
        province: "NL",
    },

    checkin: {
        date: "2024-03-20",
    },

    checkout: {
        date: "2024-03-24",
    },

    calcage: function() {
        const today = new Date();
        const birthdate = new Date(this.birthdate);
        let age = today.getFullYear() - birthdate.getFullYear();
        const monthchange = today.getMonth() - birthdate.getMonth();
        if (
            monthchange < 0 ||
            (monthchange === 0 && today.getDate() < birthdate.getDate())
        ) {
            age--;
    }
        return age,
    },

    calcStay: function () {
        const checkindate = new Date(this.checkindate);
        const checkoutdate = new Date(this.checkindate);
        const motelstay = checkoutdate - checkindate;
        const staylength = math.floor(motelstay / (1000 * 60 * 60 * 24));
        return staylength;
    },

};

const customerdescription =`

    Name: ${MotelCustomor.cname}
    Address: ${MotelCustomor.mailingaddress.streetaddress}, ${MotelCustomor.mailingaddress.town}, ${MotelCustomor.mailingaddress.province}, ${MotelCustomor.mailingaddress.postalcode}
    Gender: ${MotelCustomor.gender}
    Age: ${MotelCustomor.calcage}
    Room Preferences: ${MotelCustomor.roompreference}
    Payment Method: ${MotelCustomor.cpayment}
    Phone Number: ${MotelCustomor.phonenumber}
    Check-In Date: ${MotelCustomor.checkin.date}
    Check-Out Date: ${MotelCustomor.checkout.date}
    Length Of Stay: ${MotelCustomor.calcStay()} days
    `;

    console.log(customerdescription);

